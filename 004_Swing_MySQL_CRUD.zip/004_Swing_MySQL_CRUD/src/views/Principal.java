package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTable;

public class Principal {

	public JFrame frmVentanaPrincipal;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frmVentanaPrincipal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVentanaPrincipal = new JFrame();
		frmVentanaPrincipal.getContentPane().setBackground(Color.PINK);
		frmVentanaPrincipal.setBounds(100, 100, 450, 300);
		frmVentanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmVentanaPrincipal.getContentPane().setLayout(null);
		
		JLabel lblAccesoOk = new JLabel("ACCESO OK");
		lblAccesoOk.setBounds(26, 30, 130, 41);
		frmVentanaPrincipal.getContentPane().add(lblAccesoOk);
		
		table_1 = new JTable();
		table_1.setBounds(159, 84, 231, 148);
		frmVentanaPrincipal.getContentPane().add(table_1);
	}
}
