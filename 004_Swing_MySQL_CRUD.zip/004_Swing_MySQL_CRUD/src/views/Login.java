
package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;

import config.Conexion;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frmAccesoADatos;
	private JTextField txtUsuario;
	private JTextField txtPassword;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAccesoADatos.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccesoADatos = new JFrame();
		frmAccesoADatos.getContentPane().setBackground(Color.PINK);
		frmAccesoADatos.getContentPane().setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usuario:");
		lblUsuario.setBounds(65, 60, 62, 14);
		frmAccesoADatos.getContentPane().add(lblUsuario);
		
		JLabel lblContrase�a = new JLabel("Contrase\u00F1a:");
		lblContrase�a.setBounds(65, 97, 73, 14);
		frmAccesoADatos.getContentPane().add(lblContrase�a);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(187, 57, 128, 20);
		frmAccesoADatos.getContentPane().add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(187, 94, 128, 20);
		frmAccesoADatos.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		btnNewButton = new JButton("Acceder");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				acceder();
			}
		});
		btnNewButton.setBounds(187, 152, 128, 36);
		frmAccesoADatos.getContentPane().add(btnNewButton);
		frmAccesoADatos.setTitle("Acceso a Datos");
		frmAccesoADatos.setBounds(100, 100, 450, 300);
		frmAccesoADatos.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void acceder() {
		Connection conn = new Conexion().conectar();
		
		try {
			PreparedStatement ps = (PreparedStatement) conn.prepareStatement("SELECT * FROM user WHERE username=? AND password=?");
			ps.setString(1, txtUsuario.getText());
			ps.setString(2, txtPassword.getText());
			
			ResultSet rs = ps.executeQuery(); //EJECUTAR LA SELECT
			
			//System.out.println(rs.next());
			
			if(rs.next()) {
				Principal p = new Principal();
				p.frmVentanaPrincipal.setVisible(true);
			}else {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // CIERRA ACCEDER()
} // CIERRA CLASE
